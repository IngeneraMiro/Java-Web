package softuni.workshop.web.models;

public class UserLoginModel {
    //TODO
}
