package softuni.workshop.constants;

public class GlobalConstants {
    public static final String XML_COMPANIES_PATH = "src\\main\\resources\\files\\xmls\\companies.xml";
    public static final String XML_EMPLOYEE_PATH = "src\\main\\resources\\files\\xmls\\employees.xml";
    public static final String XML_PROJECT_PATH = "src\\main\\resources\\files\\xmls\\projects.xml";
}
