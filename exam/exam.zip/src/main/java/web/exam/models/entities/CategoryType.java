package web.exam.models.entities;

public enum CategoryType {
    FOOD,DRINK,HOUSEHOLD,OTHER
}
