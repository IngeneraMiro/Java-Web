package web.exam.models.bindmodels;

public class UserLogBindModel {

    private String username;
    private String password;

    public UserLogBindModel() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
