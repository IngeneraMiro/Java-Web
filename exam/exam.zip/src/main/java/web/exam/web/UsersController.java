package web.exam.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import web.exam.models.bindmodels.UserBindModel;
import web.exam.models.bindmodels.UserLogBindModel;
import web.exam.models.entities.User;
import web.exam.services.UserService;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/users")
public class UsersController {
    private final UserService userService;

    @Autowired
    public UsersController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/register")
    public String register(Model model, HttpSession session, RedirectAttributes redirectAttributes){

       if(!model.containsAttribute("userBindModel")){
           model.addAttribute("userBindModel",new UserBindModel());
       }

       return "register";
   }

   @PostMapping("register")
    public String regConfirm(@Valid @ModelAttribute("userBindModel")UserBindModel userBindModel,
                             BindingResult result,HttpSession session,
                             RedirectAttributes redirectAttributes){
       if(result.hasErrors()){
           redirectAttributes.addFlashAttribute("userBindModel",userBindModel);
           redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.org.springframework.validation.BindingResult.userBindModel",result);
           return "redirect:register";
       }
       if(!userBindModel.getPassword().equals(userBindModel.getConfirmPassword())){
           redirectAttributes.addFlashAttribute("userBindModel",userBindModel);
           redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.org.springframework.validation.BindingResult.userBindModel",result);
           result.rejectValue("password", "error.userRegisterBindingModel", "Password did not match");
           return "redirect:register";
       }

       try{
         User user =  this.userService.addUser(userBindModel);
       }catch (Exception e){
           return "register";
       }
       return "login";
   }

   @GetMapping("/login")
    public String login(Model model,HttpSession session,RedirectAttributes redirectAttributes){

        if(!model.containsAttribute("userLogBindModel")){
            model.addAttribute("userLogBindModel",new UserLogBindModel());
            redirectAttributes.addFlashAttribute("noUser",false);
        }

       return "login";
   }

   @PostMapping("/login")
    public String logConfirm(@Valid @ModelAttribute("")UserLogBindModel userLogBindModel,
                             BindingResult result,HttpSession session,
                             RedirectAttributes redirectAttributes){
        if(result.hasErrors()){
            redirectAttributes.addFlashAttribute("userLogBindModel",userLogBindModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.org.springframework.validation.userLogBindModel",result);
             return "redirect:login";
        }
        User user = this.userService.logUser(userLogBindModel.getUsername(),userLogBindModel.getPassword());
        if(user == null){
            redirectAttributes.addFlashAttribute("userLogBindModel",userLogBindModel);
            redirectAttributes.addFlashAttribute("noUser",true);
            return "redirect:login";
        }
        session.setAttribute("userId",user.getId());
        return "home";
   }

    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:login";
    }

}
